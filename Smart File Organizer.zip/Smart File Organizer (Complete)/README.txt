To use the file organizer simply copy the path of whichever folder you want organized and the program will
seperate the files into seperate folders based on their types.

If you are confused about anything please look at the showcase video.