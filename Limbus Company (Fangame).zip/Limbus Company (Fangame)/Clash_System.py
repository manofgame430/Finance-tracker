import random
from Characters_skills import skill_change, color_fixers
game_start = False
white, orange, monochrome, red, gold, black, green, silver, teal, yellow = color_fixers

def start_game():
    global game_start
    global hp1
    global hp2
    global player1
    global player2
    if game_start == False:
        print(f'''\n1 = {white.name}
2 = {orange.name}
3 = {monochrome.name}
4 = {red.name}
5 = {gold.name}
6 = {black.name}
7 = {green.name}
8 = {silver.name}
9 = {teal.name}
10 = {yellow.name}\n''')
        try:
            player1 = int(input("Player 1 Please select your Character: "))
            player2 = int(input("Player 2 Please select your Character: "))
        except ValueError or TypeError:
            print("\nPlease input a Number\n")
            start_game()
        if (not isinstance(player1, int) or (player1 > 10 or player1 < 0)) or (not isinstance(player1, int) or (player2 > 10 or player2 < 0)):
            print("\nPlease input a valid number\n")
            start_game()
        player1 = color_fixers[(player1 -1)]
        player2 = color_fixers[(player2 -1)]
        hp1 = (player1).current_stats["HP"]
        hp2 = (player2).current_stats["HP"]
        game_start = True
        return

start_game()

while game_start == True:
        if player1.Clash(player2) == True:
            reset = input("\nWould you like to try again?(Type yes), select a different character(Type no), or quit (Type quit) ")
            if reset.lower() == "yes":
                skill_change()
            elif reset.lower() == "no":
                game_start = False
                skill_change()
                start_game()
            elif reset.lower() == "quit":
                break