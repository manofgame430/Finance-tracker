import random
import Status_effects
player1_pos = 2
player1_neg = 1
player2_pos = 2
player2_neg = 1
loop = 0
coin_count1 = 0
coin_count2 = 0
base_power1 = 0
base_power2 = 0
game_start = False

class Character:

    def __init__(self, name, hp, skill_list):
        self.name = name
        self.hp = hp
        self.skill_list = skill_list
        self.active_status = []

    def is_alive(self):
        if self.hp > 0:
            print(f"{self.name} has {self.hp}HP")
        else:
            print(f"{self.name} has died!")

    def take_dmg(self, incoming_dmg):
        self.hp = max(0, self.hp - incoming_dmg)

    def attack(self, target, damage):
        target.hp -= damage

#Name, base_power, coins, coinpower (status_effect) add later
class skills:
    def __init__(self, name, base_power, coins, coinpower):
        self.name = name
        self.base_power = base_power
        self.coins = coins
        self.coinpower = coinpower


class Status_effect:
    def __init__(self, name, damage, duration):
        self.name = name
        self.damage = damage
        self.duration = duration

    def apply(self, target):
        print(f"{self.name} has been applied to {target.name}.")

    def turn(self, target):
        target.hp -= self.damage
        self.duration -= 1
    
    def expire(self):
        if self.duration == 0:
            print(f"{self.name} has expired")
            self.damage = 0
        


#The White Mage skills
white_s1= skills("Fire Bolt", 3, 6, 4)
white_s2= skills("Mage Hand", 5, 2, 5)
white_s3= skills("Alchemy", 10, 1, 15)
w_list = [white_s1, white_s2, white_s3]
white_skill_list = random.choice(w_list)

#The Orange Horizon skills
orange_s1 = skills("Bullseye", 3, 3, 3)
orange_s2 = skills("High Noon", 4, 2, 6)
orange_s3 = skills("Dead Ringer", 8, 3, 7)
o_list = [orange_s1, orange_s2, orange_s3]
orange_skill_list = random.choice(o_list)

#The Monochrome Detective skills
monochrome_s1 = skills("Windup", 2, 5, 2)
monochrome_s2 = skills("Red Reaper", 6, 3, 4)
monochrome_s3 = skills("Paint the World Red", 9, 2, 8)
m_list = [monochrome_s1, monochrome_s2, monochrome_s3]
monochrome_skill_list = random.choice(m_list)

#The Red Painter skills
red_s1 = skills("The world is my canvas", 2, 7, 2)
red_s2 = skills("Pick up your brush", 5, 2, 5)
red_s3 = skills("PAINT THE WORLD RED!!!!", 7, 7, 3)
r_list = [red_s1, red_s2, red_s3]
red_skill_list  = random.choice(r_list)

#The Golden Gambler skills
gold_s1 = skills("Chekhov's Gun", 4, 3, 4)
gold_s2 = skills("Infinite Ricochet", 6, 2, 6)
gold_s3 = skills("Wonder Of U", 7, 3, 7)
gld_list = [gold_s1, gold_s2, gold_s3]
gold_skill_list = random.choice(gld_list)

#The Black Plague skills
black_s1 = skills("Scientific Interest", 7, 3, 3)
black_s2 = skills("Nothing there", 6, 5, 4)
black_s3 = skills("CAN'T ESCAPE FROM CROSSING FATE", 17, 1, 18)
blk_list = [black_s1, black_s2, black_s3]
black_skill_list = random.choice(blk_list)

#The Green Apocalypse skills
green_s1 = skills("Become death destroyer of worlds", 3, 7, 2)
green_s2 = skills("A Desicive Weapon", 6, 4, 8)
green_s3 = skills("War Without Reason", 12, 3, 13)
grn_list = [green_s1, green_s2, green_s3]
green_skill_list = random.choice(grn_list)

#The Silver Monarch skills
silver_s1 = skills("Ashes to Ashes", 4, 4, 3)
silver_s2 = skills("Kingdom of Cinder", 3, 3, 7)
silver_s3 = skills("Temporal Displacment", 18, 4, 18)
slvr_list = [silver_s1, silver_s2, silver_s3]
silver_skill_list = random.choice(slvr_list)

#The Teal Tower skills
teal_s1 = skills("Impass", 6, 5, 4)
teal_s2 = skills("Wall of Iron Will", 6, 4, 7)
teal_s3 = skills("Indomitable Human Spirit", 7, 5, 5)
teal_list = [teal_s1, teal_s2, teal_s3]
teal_skill_list = random.choice(teal_list)

#The Yellow Wanderer skills
yellow_s1 = skills("Nail and Hammer", 5, 3, 3)
yellow_s2 = skills("Infite Generation", 6, 4, 8)
yellow_s3 = skills("Human Idealization", 12, 6, 8)
ylw_list = [yellow_s1, yellow_s2, yellow_s3]
yellow_skill_list = random.choice(ylw_list)

#Skill changing function
def skill_change():
    global loop
    global white_skill_list
    global orange_skill_list
    global monochrome_skill_list
    global red_skill_list
    global gold_skill_list
    global black_skill_list
    global green_skill_list
    global silver_skill_list
    global teal_skill_list
    global yellow_skill_list
    global ylw_list
    global teal_list
    global slvr_list
    global grn_list
    global blk_list
    global gld_list
    global r_list
    global w_list
    global o_list
    global m_list
    global hp1
    global hp2
    global Character
    while hp1 > 0 or hp2 > 0:
        for i in range(1):
                white_skill_list = random.choice(w_list)
                orange_skill_list = random.choice(o_list)
                monochrome_skill_list = random.choice(m_list)
                red_skill_list = random.choice(r_list)
                gold_skill_list = random.choice(gld_list)
                black_skill_list = random.choice(blk_list)
                green_skill_list = random.choice(grn_list)
                silver_skill_list = random.choice(slvr_list)
                teal_skill_list = random.choice(teal_list)
                yellow_skill_list = random.choice(ylw_list)
                white.skill_list = white_skill_list
                orange.skill_list = orange_skill_list
                monochrome.skill_list = monochrome_skill_list
                red.skill_list = red_skill_list
                gold.skill_list = gold_skill_list
                black.skill_list = black_skill_list
                green.skill_list = green_skill_list
                silver.skill_list = silver_skill_list
                teal.skill_list = teal_skill_list
                yellow.skill_list = yellow_skill_list
        break


#Characters name, hp, skill_list 
#When referencing a new character make sure to assign them to a variable so you can reference their values
white = Character("The White Mage", 35, white_skill_list)
orange = Character("The Orange Horizon", 50, orange_skill_list)
monochrome = Character("The Monochrome Detective", 40, monochrome_skill_list)
red = Character("The Red Painter", 45, red_skill_list)
gold = Character("The Golden Gambler", 40, gold_skill_list)#Roul
black = Character("The Black Plague", 60, black_skill_list)#Yarhman
green = Character("The Green Apocalypse", 55, green_skill_list)#Geiger
silver = Character("The Silver Monarch", 35, silver_skill_list)#Arson
teal = Character("The Teal Tower", 60, teal_skill_list)#Winston
yellow = Character("The Yellow Wanderer", 55, yellow_skill_list)#Kromer

#The list of color fixer characters must always be below the actual Character classes
color_fixers = [white, orange, monochrome, red, gold, black, green, silver, teal, yellow]
#Character selection screen
def start_game():
    global game_start
    global hp1
    global hp2
    global player1
    global player2
    if game_start == False:
        print(f'''\n1 = {white.name}
2 = {orange.name}
3 = {monochrome.name}
4 = {red.name}
5 = {gold.name}
6 = {black.name}
7 = {green.name}
8 = {silver.name}
9 = {teal.name}
10 = {yellow.name}\n''')
        try:
            player1 = int(input("Player 1 Please select your Character: "))
            player2 = int(input("Player 2 Please select your Character: "))
        except ValueError or TypeError:
            print("\nPlease input a Number\n")
            start_game()
        if (not isinstance(player1, int) or (player1 > 10 or player1 < 0)) or (not isinstance(player1, int) or (player2 > 10 or player2 < 0)):
            print("\nPlease input a valid number\n")
            start_game()
        player1 = color_fixers[(player1 -1)]
        player2 = color_fixers[(player2 -1)]
        hp1 = (player1).hp
        hp2 = (player2).hp
        game_start = True
        return


start_game()

if game_start == True:
    while hp1 > 0 or hp2 > 0:
        while coin_count1 < (player1).skill_list.coins:
            if random.randint(player1_neg, player1_pos) >= 2:
                print("+"+str((player1).skill_list.coinpower)+" coin power")
                base_power1 = base_power1 + (player1).skill_list.coinpower
                coin_count1 += 1
            else:
                print("Tails")
                coin_count1 += 1

        while coin_count2 < (player2).skill_list.coins:
            if random.randint(player2_neg, player2_pos) >= 2:
                print("+"+str((player2).skill_list.coinpower)+" coin power")
                base_power2 = base_power2 + (player2).skill_list.coinpower
                coin_count2 += 1
            else:
                print("Tails")
                coin_count2 += 1

        if coin_count1 == (player1).skill_list.coins and coin_count2 == (player2).skill_list.coins:
            if base_power1 > base_power2:
                print((player1).name + f" wins the clash with a {base_power1}")
                hp2 = max(0, hp2 - base_power1)
                coin_count1 = 0
                coin_count2 = 0
                base_power1 = (player1).skill_list.base_power
                base_power2 = (player2).skill_list.base_power
                skill_change()
                if hp2 == 0:
                    print("Congratulations! "+(player1).name+" has won the battle") 
                elif hp2 > 0:
                    print((player2).name+f" remaining health {hp2}")
            elif base_power1 == base_power2:
                print(f"Both players have tied with a {base_power1} and a {base_power2}")
                coin_count1 = 0
                coin_count2 = 0
                base_power1 = (player1).skill_list.base_power
                base_power2 = (player2).skill_list.base_power 
                skill_change()
            else:
                print((player2).name+f" wins the clash with a {base_power2}")
                hp1 = max(0, hp1 - base_power2)
                coin_count1 = 0
                coin_count2 = 0
                base_power1 = (player1).skill_list.base_power
                base_power2 = (player2).skill_list.base_power
                skill_change()
                if hp1 == 0:
                    print("Congratulations! "+(player2).name+" has won the battle!")
                elif hp1 > 0:
                    print((player1).name+f" remaining health {hp1}") 
        if hp1 == 0 or hp2 == 0:
            reset = input("Would you like to try again?(Type yes) or would you like to select a different character(Type no) ")
            if reset == "yes":
                skill_change()
                hp1 = (player1).hp
                hp2 = (player2).hp
                loop += 1
            elif reset == "no":
                hp1 = 0
                hp2 = 0
                loop += 1
                game_start = False
                skill_change()
                start_game()