import random
from Status_effects import DOT, Buffs_and_Debuffs, sinking, burn, DOT_list, Buffs_and_Debuffs_list
pos = 2
neg = 1
turn = 10
sinking = sinking

def skill_change():
    global white_skill_list
    global orange_skill_list
    global monochrome_skill_list
    global red_skill_list
    global gold_skill_list
    global black_skill_list
    global green_skill_list
    global silver_skill_list
    global teal_skill_list
    global yellow_skill_list
    global hp1
    global hp2
    while True:
        for i in range(1):
                white_skill_list = random.choice(w_list)
                orange_skill_list = random.choice(o_list)
                monochrome_skill_list = random.choice(m_list)
                red_skill_list = random.choice(r_list)
                gold_skill_list = random.choice(gld_list)
                black_skill_list = random.choice(blk_list)
                green_skill_list = random.choice(grn_list)
                silver_skill_list = random.choice(slvr_list)
                teal_skill_list = random.choice(teal_list)
                yellow_skill_list = random.choice(ylw_list)
                white.skill_list = white_skill_list
                orange.skill_list = orange_skill_list
                monochrome.skill_list = monochrome_skill_list
                red.skill_list = red_skill_list
                gold.skill_list = gold_skill_list
                black.skill_list = black_skill_list
                green.skill_list = green_skill_list
                silver.skill_list = silver_skill_list
                teal.skill_list = teal_skill_list
                yellow.skill_list = yellow_skill_list
        break



class skills:
    def __init__(self, name, base_power, coins, coinpower, status_effect):
        self.name = name
        self.base_power = base_power
        self.coins = coins
        self.coinpower = coinpower
        self.status_effect = status_effect

class Character:

    def __init__(self, name, hp, sanity, skill_list):
        self.name = name
        self.stats = {
            "HP": hp,
            "Sanity": sanity
        }
        self.sanity = sanity
        self.skill_list = skill_list
        self.skills = skills
        self.active_status = []

    def is_alive(self):
        if self.hp > 0:
            print(f"{self.name} has {self.hp}HP")
        else:
            print(f"{self.name} has died!")

    def take_dmg(self, incoming_dmg):
        self.stats["HP"] = max(0, self.stats["HP"] - incoming_dmg)

    def tick(self):
        for i in self.active_status:
            if i in DOT_list:
                for effect in DOT_list:
                    if i == effect:
                        for colour in color_fixers:
                            if self.name == colour.name:
                                i.apply(colour)
            elif i in Buffs_and_Debuffs_list:
                for effect2 in Buffs_and_Debuffs_list:
                    if i == effect2:
                        for colour in color_fixers:
                            if self.name == colour.name:
                                i.apply(colour)

    def apply_status(self, status):
            self.active_status.append(status)
            print(f"{self.name} has been afflicted with "+status.name)

    @property
    def current_stats(self):
        stats = self.stats.copy()

        for effect in self.active_status:
            effect.turn_end()
            if isinstance(type(effect), DOT):
                effect.tick()
            elif isinstance(type(effect), Buffs_and_Debuffs):
                effect.tick()
        return stats

    @property
    def turn_end(self):
#Code below is used to merge together duplicate status effects
        condition2 = 0
        for status in set(self.active_status):
            counter = 0
            condition = 0
            condition2 += 1
            for status2 in self.active_status:
                condition += 1
                if status == status2:
                    counter += 1
                if counter >= 2:
                    if isinstance(status, DOT):
                        self.active_status[condition2 -1].DOT_damage["HP"] += self.active_status[condition -1].DOT_damage["HP"]
                        self.active_status[condition2 -1].duration += self.active_status[condition -1].duration
                        self.active_status.remove(status2)
                    elif isinstance(status, Buffs_and_Debuffs):
                        self.active_status[condition2 -1].stat_mod["Sanity"] += self.active_status[condition -1].stat_mod["Sanity"]
                        self.active_status[condition2 -1].duration += self.active_status[condition -1].duration
                        self.active_status.remove(status2)
#Code below is used to activate each of the status effects inside active_status
        if len(self.active_status) == 0:
            return 0
        else:
            for effect in self.active_status:
                if isinstance(effect, DOT):
                    print(f"{self.name} took {self.active_status[condition2 -1].DOT_damage["HP"]} damage from {status.name}")
                elif isinstance(effect, Buffs_and_Debuffs):
                    print(f"{self.name} recieved -{self.active_status[condition2 -1].stat_mod["Sanity"]} to {next(iter(status.stat_mod))}")
        ac_length = len(self.active_status)
        for i in range(ac_length):
            self.tick()
            if isinstance(status, DOT):
                 for key2, value in self.stats.items():
                    for key3, value in self.active_status[condition2 -1].DOT_damage.items():
                        if key2 == key3:
                            return self.active_status[condition2 -1].DOT_damage["HP"]
            elif isinstance(status, Buffs_and_Debuffs):
                for key, value in self.stats.items():
                    for key1, value in self.active_status[condition2 -1].stat_mod.items():
                        if key == key1:
                            return self.active_status[condition2 -1].stat_mod["Sanity"]
#Code below is used to lower duration of all statuses by 1
        for status in self.active_status:
            status.duration -= 1
            if status.duration <= 0:
                self.active_status.remove(status)
                print(f"{status.name} has been removed from {self.name}")

    def Clash(self, enemy:Character):
        win = False
        self.sanity = 0
        enemy.sanity = 0
        base_1 = self.skill_list.base_power
        base_2 = enemy.skill_list.base_power
        hp1 = self.current_stats["HP"]
        hp2 = enemy.current_stats["HP"]
        def take_dmghp1(incoming_damage):
            nonlocal hp1
            hp1 = max(0, hp1 - incoming_damage)
        def take_dmghp2(incoming_damage):
            nonlocal hp2
            hp2 = max(0, hp2 -incoming_damage)
        neg, pos = self.check_sanity()
        e_neg, e_pos = enemy.check_sanity()
        coin_count = 0
        coin_count2 = 0
        max(-45, min(self.stats["Sanity"], 45))
        max(-45, min(enemy.sanity, 45))
        while hp1 > 0 or hp2 > 0:
            while coin_count < self.skill_list.coins:
                if random.randint(neg, pos) > 0:
                    print(f"+{self.skill_list.coinpower} clash power")
                    base_1 += self.skill_list.coinpower
                    coin_count += 1
                else:
                    print("Tails")
                    coin_count += 1


            while coin_count2 < enemy.skill_list.coins:
                if random.randint(e_neg, e_pos) > 0:
                    print(f"+{enemy.skill_list.coinpower} clash power")
                    base_2 += enemy.skill_list.coinpower
                    coin_count2 += 1
                else:
                    print("Tails")
                    coin_count2 += 1


            if coin_count == self.skill_list.coins and coin_count2 == enemy.skill_list.coins:
                #Player clash win
                if base_1 > base_2:
                    print(f"{self.name} has won the clash with {base_1} clash power!")
                    hp2 = max(0, hp2 - base_1)
                    self.stats["Sanity"] += (10 + (2 * enemy.skill_list.coins))
                    enemy.stats["Sanity"] -= (2 * enemy.skill_list.coins)
                    neg, pos = self.check_sanity()
                    e_neg, e_pos = enemy.check_sanity()
                    max(-45, min(self.stats["Sanity"], 45))
                    max(-45, min(enemy.stats["Sanity"], 45))
                    if hp2 == 0:
                        print(f"Congratulations! {self.name} has won the battle")
                        win = True
                        return win
                    elif hp2 > 0:
                        print(f"{enemy.name} remaining health {hp2}")
                        if self.skill_list.status_effect != None:
                            enemy.apply_status(self.skill_list.status_effect)
                        else:
                            pass
                    coin_count = 0
                    coin_count2 = 0
                    self.turn_end
                    self.current_stats
                    take_dmghp2(enemy.turn_end)
                    enemy.current_stats
                    skill_change()
                    base_1 = self.skill_list.base_power
                    base_2 = enemy.skill_list.base_power

                #Enemy clash win
                elif base_2 > base_1:
                    print(f"{enemy.name} has won the clash with {base_2} clash power!")
                    hp1 = max(0, hp1 - base_2)
                    enemy.stats["Sanity"] += (10 + (2 * self.skill_list.coins))
                    self.stats["Sanity"] -= (2 * self.skill_list.coins)
                    neg, pos = self.check_sanity()
                    e_neg, e_pos = enemy.check_sanity()
                    max(-45, min(self.stats["Sanity"], 45))
                    max(-45, min(enemy.stats["Sanity"], 45))
                    if hp1 == 0:
                        print(f"Congratulations! {enemy.name} has won the battle")
                        win = True
                        return win
                    elif hp1 > 0:
                        print(f"{self.name} remaining health {hp1}")
                        if enemy.skill_list.status_effect != None:
                            self.apply_status(enemy.skill_list.status_effect)
                        else:
                            pass
                    coin_count = 0
                    coin_count2 = 0
                    take_dmghp1(self.turn_end)
                    self.current_stats
                    enemy.turn_end
                    enemy.current_stats
                    skill_change()
                    base_1 = self.skill_list.base_power
                    base_2 = enemy.skill_list.base_power
                #Tied
                elif base_2 == base_1:
                    print(f"Both fixers have tied with {base_1} clash power!")
                    coin_count = 0
                    coin_count2 = 0
                    self.turn_end
                    self.current_stats
                    enemy.turn_end
                    enemy.current_stats
                    skill_change()
                    base_1 = self.skill_list.base_power
                    base_2 = enemy.skill_list.base_power

    def check_sanity(self):
        pos = 1
        neg = 1
        count = 0
        max(-45, min(self.stats["Sanity"], 45))
        if self.stats["Sanity"] <= -45:
            self.stats["Sanity"] = 0 
            return -neg, pos
#Code below changes pos and negative values in coin flip based on amount of sanity
        if self.stats["Sanity"] > 0:
            if self.stats["Sanity"] >= 45:
                pos = 9
                self.stats["Sanity"] = 45
                return -neg, pos
            else:
                for i in range(self.stats["Sanity"]):
                    count += 1
                    if count == 5:
                        pos += 1
                        count = 0
                return -neg, pos
        elif self.stats["Sanity"] < 0:
            if self.stats["Sanity"] <= -45:
                neg = 9
                self.stats["Sanity"] = 0
                return -neg, pos
            else:
                for i in range(abs(self.stats["Sanity"])):
                    count += 1
                    if count == 5:
                        neg += 1
                        count = 0
                return -neg, pos
        else:
            return -neg, pos


#Order of parameters is: Name, base_power, coins, coinpower, (status_effect)
#The White Mage skills
white_s1= skills("Fire Bolt", 3, 6, 4, burn)
white_s2= skills("Mage Hand", 5, 2, 5, None)
white_s3= skills("Alchemy", 10, 1, 15, None)
w_list = [white_s1, white_s2, white_s3]
white_skill_list = random.choice(w_list)

#The Orange Horizon skills
orange_s1 = skills("Bullseye", 3, 3, 3, None)
orange_s2 = skills("High Noon", 4, 2, 6, None)
orange_s3 = skills("Dead Ringer", 8, 3, 7, None)
o_list = [orange_s1, orange_s2, orange_s3]
orange_skill_list = random.choice(o_list)

#The Monochrome Detective skills
monochrome_s1 = skills("Windup", 2, 5, 2, sinking)
monochrome_s2 = skills("Red Reaper", 6, 3, 4, sinking)
monochrome_s3 = skills("Paint the World Red", 9, 2, 8, sinking)
m_list = [monochrome_s1, monochrome_s2, monochrome_s3]
monochrome_skill_list = random.choice(m_list)

#The Red Painter skills
red_s1 = skills("The world is our canvas...", 2, 7, 2, None)
red_s2 = skills("... so, Pick up your brush...", 5, 2, 5, None)
red_s3 = skills("...AND PAINT THE WORLD RED!!!!", 7, 7, 3, None)
r_list = [red_s1, red_s2, red_s3]
red_skill_list  = random.choice(r_list)

#The Golden Gambler skills
gold_s1 = skills("Chekhov's Gun", 4, 3, 4, None)
gold_s2 = skills("Infinite Ricochet", 6, 2, 6, None)
gold_s3 = skills("Wonder Of U", 7, 3, 7, None)
gld_list = [gold_s1, gold_s2, gold_s3]
gold_skill_list = random.choice(gld_list)

#The Black Plague skills
black_s1 = skills("Scientific Interest", 7, 3, 3, None)
black_s2 = skills("Nothing there", 6, 5, 4, None)
black_s3 = skills("CAN'T ESCAPE FROM CROSSING FATE", 17, 1, 18, None)
blk_list = [black_s1, black_s2, black_s3]
black_skill_list = random.choice(blk_list)

#The Green Apocalypse skills
green_s1 = skills("Become death destroyer of worlds", 3, 7, 2, burn)
green_s2 = skills("A Desicive Weapon", 6, 4, 8, burn)
green_s3 = skills("War Without Reason", 12, 3, 13, burn)
grn_list = [green_s1, green_s2, green_s3]
green_skill_list = random.choice(grn_list)

#The Silver Monarch skills
silver_s1 = skills("Ashes to Ashes", 4, 4, 3, burn)
silver_s2 = skills("Kingdom of Cinder", 3, 3, 7, burn)
silver_s3 = skills("Temporal Displacment", 18, 4, 18, None)
slvr_list = [silver_s1, silver_s2, silver_s3]
silver_skill_list = random.choice(slvr_list)

#The Teal Tower skills
teal_s1 = skills("Impass", 6, 5, 4, None)
teal_s2 = skills("Wall of Iron Will", 6, 4, 7, None)
teal_s3 = skills("Indomitable Human Spirit", 7, 5, 5, None)
teal_list = [teal_s1, teal_s2, teal_s3]
teal_skill_list = random.choice(teal_list)

#The Yellow Wanderer skills
yellow_s1 = skills("Nail and Hammer", 5, 3, 3, None)
yellow_s2 = skills("Obsessive Compulsion", 6, 4, 8, None)
yellow_s3 = skills("Human Idealization", 12, 6, 8, None)
ylw_list = [yellow_s1, yellow_s2, yellow_s3]
yellow_skill_list = random.choice(ylw_list)

#Characters name, hp, sanity, skill_list 
white = Character("The White Mage", 35, 0, white_skill_list)
orange = Character("The Orange Horizon", 50, 0, orange_skill_list)
monochrome = Character("The Monochrome Detective", 40, 0, monochrome_skill_list)
red = Character("The Red Painter", 45, 0, red_skill_list)
gold = Character("The Golden Gambler", 40, 0, gold_skill_list)
black = Character("The Black Plague", 60, 0, black_skill_list)
green = Character("The Green Apocalypse", 55, 0, green_skill_list)
silver = Character("The Silver Monarch", 35, 0, silver_skill_list)
teal = Character("The Teal Tower", 60, 0, teal_skill_list)
yellow = Character("The Yellow Wanderer", 55, 0, yellow_skill_list)

color_fixers = [white, orange, monochrome, red, gold, black, green, silver, teal, yellow]