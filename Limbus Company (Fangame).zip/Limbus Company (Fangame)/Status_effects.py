import Characters_skills
#Used for changing stuff like offense levels and Sanity
class Status_effect:
    def __init__(self, name, duration):
        self.name = name
        self.duration = duration

    def apply(target):
        duration += 1
    
    def turn_end(self):
        self.duration -= 1
        return self.duration > 0

#DOT = Damage over time. Used for stuff like burn
class DOT(Status_effect):
    def __init__(self, name, duration, DOT_damage):
        super().__init__(name, duration)
        self.DOT_damage = DOT_damage

    def apply(self, player):
        player.take_dmg(self.DOT_damage["HP"])



class Buffs_and_Debuffs(Status_effect):
    def __init__(self, name, duration, stat_mod):
        super().__init__(name, duration)
        self.stat_mod = stat_mod or {}

    def apply(self, character:Characters_skills.Character):
        for stat, value in character.stats.items():
            for key, value2 in self.stat_mod.items():
                if stat == key:
                    character.stats[key] -= self.stat_mod[key]
                else:
                    pass


#Status effects
burn = DOT("Burn", 5, {"HP": 5})
sinking = Buffs_and_Debuffs("Gloom", 1, {"Sanity": 1})
DOT_list = [burn]
Buffs_and_Debuffs_list = [sinking]