There isn't really much the user has to do in this program as it was more of a project I used to test my capabilites as a coder.

Start the program and choose your character then watch the outcome of the battle.

There might be some slight hiccups that happen to the code from time to time as this was made on my own with me learning as I worked on it.

This was made during my first month or so of Base Camp Coding Academy which is why some code might feel inefficent or redundent,
however I still feel extremely proud of what I have accomplished which is why this project is on my portfolio.