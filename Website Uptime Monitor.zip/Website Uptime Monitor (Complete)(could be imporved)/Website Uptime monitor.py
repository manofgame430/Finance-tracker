import requests
import time
import winsound # For alarms

sites = [
    "https://www.google.com",
    "https://www.github.com",
    "https://site-that-does-not-exist.com"
]

print("Website Monitor Started...")
check_interval = 5

def check_sites():
    for site in sites:
        try:
            #send get request
            response = requests.get(site, timeout=3)

            #Check Status (200 = ok)
            if response.status_code == 200:
                print(f"UP: {site}")
            else:
                print(f"DOWN ({response.status_code}): {site}")
                winsound.Beep(1000, 500) #Beep if website is down
        except requests.exceptions.ConnectionError:
            print(f"FAILURE: {site} (Connection Error)")
            winsound.Beep(2000, 1000) #Long Beep for crash
while True:
    check_sites()
    print("-"*30)
    time.sleep(check_interval)