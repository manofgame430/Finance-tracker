The way to use this is fairly simple.

You put the url of the website you want to check into the list labeled sites.
(Make sure each of them is seperated by a comma)

Next you can change the amount of seconds the program waits to perform its next check by changing the check_interval varible.

The program will give you a short beep if the website is down and a long beep if the website has crashed.

Finally just run the program and wait for either a beep or silece.
(check the terminal to get an idea of which website is down or has crashed)