import sqlite3
import datetime

def choice_validation(choice:str, amount_of_choices:int)->int:
    while True:
        if choice.isdigit():
            if int(choice) <= amount_of_choices and int(choice) > 0:
                return int(choice)
        print("\nPlease insert a valid numerical choice.")
        choice = input("> ")

conn = sqlite3.connect("expenses.db")
cur = conn.cursor()

while True:
    print('''\nPlease select an option:
1. Insert a new expense
2. View expenses summary''')
    choice = choice_validation(input("> "), 2)
    if choice == 1:
        date = input("Enter the date of the expense in the format (YYYY-MM-DD): ")
        description = input("Enter the description of the expense: ")

        cur.execute("""CREATE TABLE IF NOT EXISTS expenses
(id INTEGER PRIMARY KEY,
Date DATE,
description TEXT,
category TEXT,
price REAL)""")

        cur.execute("SELECT DISTINCT category FROM expenses")

        categories = cur.fetchall()

        print("Select category by number:")
        for num, cat in enumerate(categories):
            print(f"{num+1}. {cat[0]}")
        print(f"{len(categories)+1}. Create a new category")

        category_choice = choice_validation(input("> "), len(categories)+1)
        if category_choice == len(categories)+1:
            category = input("Enter the new category name: ")
        else:
            category = categories[category_choice -1][0]

        price = input("Enter the price of the expense: ")

        cur.execute("INSERT INTO expenses (Date, description, category, price) VALUES (?, ?, ?, ?)", (date, description, category, price))

        conn.commit()

    elif choice == 2:
        print("\nSelect an option: ")
        print("1. View all expenses")
        print("2. View monthly expenses by category")
        view_choice = choice_validation(input("> "), 2)
        if view_choice == 1:
            try:
                cur.execute("SELECT * FROM expenses")
                expenses = cur.fetchall()
                for expense in expenses:
                    print(expense)
            except sqlite3.OperationalError:
                print("\nYou don't have any expenses")
        elif view_choice ==2:
            month = input("Enter the month (MM): ")
            year = input("Enter the year (YYYY): ")
            try:
                cur.execute("SELECT category, SUM(price) FROM expenses WHERE strftime('%m', Date) = ? AND strftime('%Y', Date) = ? GROUP BY category", (month, year))
                expenses = cur.fetchall()
                for expense in expenses:
                    print(f"Category: {expense[0]}, Total: {expense[1]}")
            except sqlite3.OperationalError:
                print("\nYou don't have any expenses")
        else:
            exit()
    else:
        exit()
    repeat = input("\nWould you like to do something else (y/n)\n")
    if repeat.lower() != "y":
        break

conn.close()
    